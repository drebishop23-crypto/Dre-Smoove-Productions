module.exports = window.ReactDOM;
